-- 2. Insert rows. -- 

/* dept */
insert into dept values ('Management',5,2001,1);
insert into dept values ('Marketing',1,2002,2);
insert into dept values ('Accounting',4,2003,5);
insert into dept values ('Purchasing',4,2004,7);
insert into dept values ('Personnel',1,2005,9);


/* emp */
insert into emp (empno, empfname, empsalary, deptname) values (1,'Alice',75000,'Management');
insert into emp values (2,'Ned',45000,'Marketing',1);
insert into emp values (3,'Andrew',25000,'Marketing',2);
insert into emp values (4,'Clare',22000,'Marketing',2);
insert into emp values (5,'Todd',38000,'Accounting',1);
insert into emp values (6,'Nancy',22000,'Accounting',5);
insert into emp values (7,'Brier',43000,'Purchasing',1);
insert into emp values (8,'Sarah',56000,'Purchasing',7);
insert into emp values (9,'Sophie',35000,'Personnel',1);


/* product */
insert into product (prodid, proddesc, prodprice) values (1000,'Animal photography kit',725);
insert into product values (101,'Camera',150,300);
insert into product values (102,'Camera case',10,15);
insert into product values (103,'70-210 zoom lens',125,200);
insert into product values (104,'28-85 zoom lens',115,185);
insert into product values (105,'Photographers vest',25,40);
insert into product values (106,'Lens cleaning cloth',1,1.25);
insert into product values (107,'Tripod',35,45);
insert into product values (108,'16 GB SDHC memory card',30,37);


/* assembly */
insert into assembly values (1,1000,101);
insert into assembly values (1,1000,102);
insert into assembly values (1,1000,103);
insert into assembly values (1,1000,104);
insert into assembly values (1,1000,105);
insert into assembly values (2,1000,106);
insert into assembly values (1,1000,107);
insert into assembly values (10,1000,108);
